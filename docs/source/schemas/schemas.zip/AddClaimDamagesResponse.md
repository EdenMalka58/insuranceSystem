# AddClaimDamagesResponse

| Field | Type | Required | Description |
|------|------|----------|-------------|
| claimNumber | string | No | Details of claimNumber |
| assessmentValue | number | No | Details of assessmentValue |
| approvedValue | number | No | Details of approvedValue |
| status | string | No | Details of status |
| damageAreas | array of :ref:`addclaimdamagesresponse-damageareas` | No | Details of damageAreas |