# GetAdminDashboardResponse_claimsOverview_datasets

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| label | string | No | Details of label |
| data | array | No | Details of data |
| borderColor | string | No | Details of borderColor |
| backgroundColor | string | No | Details of backgroundColor |
| drilldownType | string | No | Details of drilldownType |
| fill | boolean | No | Details of fill |