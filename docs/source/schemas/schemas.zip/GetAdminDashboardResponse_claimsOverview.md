# GetAdminDashboardResponse_claimsOverview

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| type | string | No | Details of type |
| labels | array | No | Details of labels |
| datasets | array of :ref:`getadmindashboardresponse-claimsoverview-datasets` | No | Details of datasets |