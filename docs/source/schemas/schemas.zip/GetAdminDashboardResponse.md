# GetAdminDashboardResponse

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| year | integer | No | Details of year |
| counters | array of :ref:`getadmindashboardresponse-counters` | No | Details of counters |
| claimsOverview | object of :ref:`getadmindashboardresponse-claimsoverview` | No | Details of claimsOverview |
| activity | array of :ref:`getadmindashboardresponse-activity` | No | Details of activity |