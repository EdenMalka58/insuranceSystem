# GetPolicyResponse

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| policy | object of :ref:`getpolicyresponse-policy` | No | Details of policy |
| claimsCount | integer | No | Details of claimsCount |
| claims | array of :ref:`getpolicyresponse-claims` | No | Details of claims |