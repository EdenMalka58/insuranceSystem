# GetAdminDashboardResponse_counters

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| id | string | No | Details of id |
| title | string | No | Details of title |
| count | integer | No | Details of count |
| amount | integer | No | Details of amount |
| color | string | No | Details of color |
| drilldown | object | No | Details of drilldown |