# AddPolicyRequest_vehicle

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| model | string | Yes | Details of model |
| year | integer | Yes | Details of year |
| plateNumber | string | Yes | Details of plateNumber |