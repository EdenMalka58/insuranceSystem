# GetPolicyResponse_policy_vehicle

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| model | string | No | Details of model |
| year | integer | No | Details of year |
| plateNumber | string | No | Details of plateNumber |