# AddClaimResponse

| Field | Type | Required | Description |
|------|------|----------|-------------|
| message | string | No | Details of message |
| claimNumber | string | No | Details of claimNumber |
| policyNumber | string | No | Details of policyNumber |
| emailSent | boolean | No | Details of emailSent |