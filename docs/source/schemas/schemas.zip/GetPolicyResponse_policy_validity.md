# GetPolicyResponse_policy_validity

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| start | string | No | Details of start |
| end | string | No | Details of end |