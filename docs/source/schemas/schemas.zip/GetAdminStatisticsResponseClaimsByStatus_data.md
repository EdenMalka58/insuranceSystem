# GetAdminStatisticsResponseClaimsByStatus_data

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| labels | array | No | Details of labels |
| datasets | array | No | Details of datasets |