# GetTokenDataRequest

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| tokenId | string | No | Details of tokenId |