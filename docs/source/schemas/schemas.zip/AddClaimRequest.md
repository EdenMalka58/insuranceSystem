# AddClaimRequest

| Field | Type | Required | Description |
|------|------|----------|-------------|
| policyNumber | string | Yes | Details of policyNumber |
| claimNumber | string | Yes | Details of claimNumber |
| claimDate | string | Yes | Details of claimDate |
| description | string | Yes | Details of description |
| assessmentValue | number | No | Details of assessmentValue |
| approvedValue | number | No | Details of approvedValue |
| damageAreas | array | No | Details of damageAreas |