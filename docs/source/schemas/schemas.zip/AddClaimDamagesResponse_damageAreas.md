# AddClaimDamagesResponse_damageAreas

| Field | Type | Required | Description |
|------|------|----------|-------------|
| area | string | No | Details of area |
| severity | string | No | Details of severity |
| estimatedCost | number | No | Details of estimatedCost |