# UpdatePolicyRequest_vehicle

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| make | string | No | Details of make |
| model | string | No | Details of model |
| year | integer | No | Details of year |
| licensePlate | string | No | Details of licensePlate |