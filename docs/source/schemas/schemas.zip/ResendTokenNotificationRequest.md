# ResendTokenNotificationRequest

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| policyNumber | string | Yes | Details of policyNumber |
| claimNumber | string | Yes | Details of claimNumber |