# AddPolicyRequest

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| policyNumber | string | Yes | Details of policyNumber |
| insured | object of :ref:`addpolicyrequest-insured` | Yes | Insured party personal and contact details |
| vehicle | object of :ref:`addpolicyrequest-vehicle` | Yes | Vehicle details covered by the policy |
| validity | object of :ref:`addpolicyrequest-validity` | Yes | Policy validity period including start and end dates |
| insuredValue | number | Yes | Total insured value of the policy |
| deductibleValue | number | Yes | Deductible amount applicable to the policy |