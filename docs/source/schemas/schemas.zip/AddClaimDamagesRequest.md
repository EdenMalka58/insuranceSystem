# AddClaimDamagesRequest

| Field | Type | Required | Description |
|------|------|----------|-------------|
| damageAreas | array of [`AddClaimDamagesRequest_damageAreas`](addclaimdamagesrequest-damageareas) | Yes | Details of damageAreas |