# AddPolicyResponse

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| message | string | No | Details of message |
| policyNumber | string | No | Details of policyNumber |