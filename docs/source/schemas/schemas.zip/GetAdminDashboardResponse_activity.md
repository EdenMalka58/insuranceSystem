# GetAdminDashboardResponse_activity

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| label | string | No | Details of label |
| count | integer | No | Details of count |
| color | string | No | Details of color |
| type | string | No | Details of type |