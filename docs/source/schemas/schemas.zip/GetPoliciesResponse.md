# GetPoliciesResponse

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| items | array | No | Details of items |
| page | integer | No | Details of page |
| pageSize | integer | No | Details of pageSize |
| total | integer | No | Details of total |
| hasNext | boolean | No | Details of hasNext |