# UpdateClaimStatusRequest

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| policyNumber | string | Yes | Details of policyNumber |
| claimNumber | string | Yes | Details of claimNumber |
| isApproved | boolean | Yes | Details of isApproved |