# GetAdminStatisticsResponse

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| claimsByStatus | object | No | Details of claimsByStatus |
| claimsByApprovedAction | object | No | Details of claimsByApprovedAction |
| claimsOverTime | object | No | Details of claimsOverTime |
| approvedValueByMonth | object | No | Details of approvedValueByMonth |
| policiesOverTime | object | No | Details of policiesOverTime |
| claimsByVehicleYear | object | No | Details of claimsByVehicleYear |
| claimsByVehicleValue | object | No | Details of claimsByVehicleValue |
| approvalRateByDeductible | object | No | Details of approvalRateByDeductible |
| avgClaimCostByVehicleValue | object | No | Details of avgClaimCostByVehicleValue |
| deductibleVsOutcome | object | No | Details of deductibleVsOutcome |