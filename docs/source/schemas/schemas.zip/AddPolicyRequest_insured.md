# AddPolicyRequest_insured

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| name | string | Yes | Details of name |
| email | string | No | Details of email |
| phone | string | No | Details of phone |
| idNumber | string | Yes | Details of idNumber |