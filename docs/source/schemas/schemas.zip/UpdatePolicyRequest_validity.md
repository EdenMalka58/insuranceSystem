# UpdatePolicyRequest_validity

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| startDate | string | No | Details of startDate |
| endDate | string | No | Details of endDate |