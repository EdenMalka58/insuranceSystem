# GetAdminDashboardResponse_drilldown

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| type | string | No | Details of type |
| value | string | No | Details of value |