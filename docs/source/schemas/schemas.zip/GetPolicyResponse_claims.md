# GetPolicyResponse_claims

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| claimNumber | string | No | Details of claimNumber |
| claimDate | string | No | Details of claimDate |
| description | string | No | Details of description |
| status | string | No | Details of status |
| approvedAction | string | No | Details of approvedAction |
| assessmentValue | number | No | Details of assessmentValue |
| approvedValue | number | No | Details of approvedValue |
| damageAreas | array | No | Details of damageAreas |
| createdAt | string | No | Timestamp when the record was created |
| updatedAt | string | No | Details of updatedAt |