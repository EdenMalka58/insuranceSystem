(addclaimdamagesrequest-damageareas)=

# AddClaimDamagesRequest_damageAreas

| Field | Type | Required | Description |
|------|------|----------|-------------|
| area | string | Yes | Details of area |
| severity | string | Yes | Details of severity |