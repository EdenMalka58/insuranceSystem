# GetAdminDashboardDrilldownResponse

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|