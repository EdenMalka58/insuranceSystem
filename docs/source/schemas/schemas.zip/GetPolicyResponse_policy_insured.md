# GetPolicyResponse_policy_insured

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| name | string | No | Details of name |
| email | string | No | Details of email |
| phone | string | No | Details of phone |
| idNumber | string | No | Details of idNumber |