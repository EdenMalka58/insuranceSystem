# DeletePolicyResponse

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| message | string | No | Details of message |