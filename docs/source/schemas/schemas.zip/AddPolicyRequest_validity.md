# AddPolicyRequest_validity

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| start | string | Yes | Details of start |
| end | string | Yes | Details of end |