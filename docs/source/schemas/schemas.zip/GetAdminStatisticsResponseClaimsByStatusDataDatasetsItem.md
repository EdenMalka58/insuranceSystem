# GetAdminStatisticsResponseClaimsByStatusDataDatasetsItem

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| label | string | No | Details of label |
| data | array | No | Details of data |