# UpdateClaimStatusResponse

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| message | string | No | Details of message |
| policyNumber | string | No | Details of policyNumber |
| claimNumber | string | No | Details of claimNumber |
| approvedValue | number | No | Details of approvedValue |
| approvedAction | string | No | Details of approvedAction |