# GetAdminStatisticsResponseClaimsByStatus

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| title | string | No | Details of title |
| type | string | No | Details of type |
| data | object of :ref:`getadminstatisticsresponseclaimsbystatus-data` | No | Details of data |
| options | object | No | Details of options |
| drilldown | object of :ref:`getadminstatisticsresponseclaimsbystatus-drilldown` | No | Details of drilldown |