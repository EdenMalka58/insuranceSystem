# GetAdminStatisticsResponseClaimsByStatus_drilldown

| Field | Type | Required | Description |
|------|------|----------|-------------|
|---|---|---|
| enabled | boolean | No | Details of enabled |
| key | string | No | Details of key |
| endpoint | string | No | Details of endpoint |